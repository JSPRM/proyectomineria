select sum(disposicion_inicial_credito) as total_disposicion, acreedor
from "PRUEBA_deudas"
GROUP BY acreedor
