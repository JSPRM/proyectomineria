SELECT sum(intereses_periodo) as intereses, anio
  FROM "PRUEBA_deudas"
  GROUP BY anio
  ORDER BY anio