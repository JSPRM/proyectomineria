SELECT sum(pago_servicio_deuda) as pago_servicio_deuda, anio, trimestre
  FROM "PRUEBA_deudas"
  GROUP BY anio, trimestre
  ORDER BY anio